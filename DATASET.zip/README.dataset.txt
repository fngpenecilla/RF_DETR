# aquarium > 2025-07-27 1:25am
https://universe.roboflow.com/purin-rcwo6/aquarium-k57xn-cnprb

Provided by a Roboflow user
License: CC BY 4.0

